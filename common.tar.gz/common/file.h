#ifndef FILE_H
#define FILE_H

void loadFileIntoMemory(char **buffer, int *sz_buffer, char *inputFile);
#endif
